import { GoogleGenAI, Type } from "@google/genai";
import type { WordDefinition } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

const definitionSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      word: {
        type: Type.STRING,
        description: "The difficult word identified from the text."
      },
      definition: {
        type: Type.STRING,
        description: "A simple Korean translation of the word, consisting of just one or two words."
      },
    },
    required: ["word", "definition"],
  },
};


export const getWordDefinitions = async (
  studentLevel: number,
  bookTitle: string,
  bookLevel: number,
  bookExcerpt: string
): Promise<WordDefinition[]> => {
  try {
    const prompt = `
      I am a student at reading level ${studentLevel}.
      I am reading a book titled "${bookTitle}", which is at level ${bookLevel}.
      Here is an excerpt from the book: "${bookExcerpt}"
      Based on my reading level and the book's complexity, please identify up to 5 potentially difficult words for me.
      For the 'definition' property of each word, you MUST provide a simple Korean translation consisting of only one or two words. Do NOT include any other text, explanations, or English.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: definitionSchema,
      },
    });
    
    const jsonString = response.text.trim();
    const definitions = JSON.parse(jsonString);

    return definitions as WordDefinition[];

  } catch (error) {
    console.error("Error fetching word definitions from Gemini API:", error);
    throw new Error("단어 뜻을 찾지 못했어요. 다시 시도해 주세요.");
  }
};

export const getDictionaryDefinition = async (word: string): Promise<string> => {
  if (!word.trim()) {
    return "";
  }
  try {
    const prompt = `Your task is to translate the English word "${word}" into its simplest Korean equivalent. 
    IMPORTANT: Your response MUST ONLY contain the one or two Korean words for the translation. 
    Do not add greetings, explanations, or any other text. 
    For example, if the word is "friend", your entire response must be "친구".`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
    });
    
    return response.text.trim();

  } catch (error) {
    console.error(`Error fetching definition for "${word}" from Gemini API:`, error);
    throw new Error(`"${word}"의 뜻을 찾지 못했어요. 다시 시도해 주세요.`);
  }
};